package com.tools;


/**
 *
 * @author zsx
 *
 * @date 2013-12-27 11:03:26
 *
 * @description 继承此类 自动在Menu加入按钮 查看 存放在assets下的文件
 */
//public abstract class Lib_Class_ShowCodeActivity extends Activity {
//    private Lib_Class_ShowCodeUtil showCode;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        showCode = new Lib_Class_ShowCodeUtil();
//        showCodeInit(showCode);
//        if (showCode.getShowJava() == null) {
//            showCode.setShowJava(this.getClass());
//        }
//    }
//
//    @Override
//    public void setContentView(int layoutResID) {
//        super.setContentView(layoutResID);
//        if (showCode.getShowXml() == null) {
//            showCode.setShowXML(layoutResID);
//        }
//    }
//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        showCode._onCreateOptionsMenu(this, menu);
//        return super.onCreateOptionsMenu(menu);
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        showCode._onOptionsItemSelected(this, item);
//        return super.onOptionsItemSelected(item);
//    }
//
//    protected void showCodeInit(Lib_Class_ShowCodeUtil showCode) {
//    }
//}
