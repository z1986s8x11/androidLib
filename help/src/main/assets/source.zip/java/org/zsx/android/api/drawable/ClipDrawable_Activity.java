package org.zsx.android.api.drawable;

import org.zsx.android.api._BaseActivity;

import android.os.Bundle;

public class ClipDrawable_Activity extends _BaseActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

}
