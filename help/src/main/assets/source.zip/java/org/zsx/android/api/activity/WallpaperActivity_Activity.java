package org.zsx.android.api.activity;

import android.os.Bundle;

import org.zsx.android.api.R;
import org.zsx.android.api._BaseActivity;

public class WallpaperActivity_Activity extends _BaseActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.util_activity_wallpaper);
	}
}
