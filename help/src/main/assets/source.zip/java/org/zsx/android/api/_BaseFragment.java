package org.zsx.android.api;


import android.support.v4.app.Fragment;

public class _BaseFragment extends Fragment {

}
