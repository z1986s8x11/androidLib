package zsx.lib.qrcode.view;


public class ScanLifeID {
	public static final int auto_focus = 0x19860811;
	public static final int decode = 0x19860812;
	public static final int decode_failed = 0x19860813;
	public static final int decode_succeeded = 0x19860814;
	public static final int encode_failed = 0x19860815;
	public static final int encode_succeeded = 0x19860816;
	public static final int launch_product_query = 0x19860817;
	public static final int quit = 0x19860818;
	public static final int restart_preview = 0x19860819;
	public static final int return_scan_result = 0x19860820;
	public static final int search_book_contents_failed = 0x19860821;
	public static final int search_book_contents_succeeded = 0x19860822;
	public static final int return_home = 0x19860823;
}
